<?php
declare(strict_types=1);
// Use private config.php when present. On local WAMP only, use safe example defaults.
$configFile=__DIR__.'/config.php';
if (!is_file($configFile)) {
    $host=strtolower((string)($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
    $host=preg_replace('/:\\d+$/', '', $host);
    if (!in_array($host, ['localhost','127.0.0.1','[::1]'], true)) {
        http_response_code(503);
        exit('TAPGLOBIA: Sunucu ayarlari eksik. config.php olusturun.');
    }
    $configFile=__DIR__.'/config.example.php';
}
$config=require $configFile;
ini_set('display_errors','0');
ini_set('log_errors','1');
if(session_status()!==PHP_SESSION_ACTIVE){session_name('TAPGLOBIA_SESS');session_set_cookie_params(['httponly'=>true,'secure'=>(bool)$config['session_secure'],'samesite'=>'Lax','path'=>'/']);session_start();}
if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24));
function db():PDO { static $pdo=null; global $config; if($pdo)return $pdo; $pdo=new PDO('mysql:host='.$config['db_host'].';port='.$config['db_port'].';dbname='.$config['db_name'].';charset=utf8mb4',$config['db_user'],$config['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); return $pdo; }
function sql(string $q,array $args=[]):PDOStatement{$s=db()->prepare($q);$s->execute($args);return $s;}
function user():?array{if(empty($_SESSION['uid']))return null;$u=sql('SELECT u.id,u.username,u.email,u.country_code,u.city_id,u.total_clicks,u.role,u.last_country_change,u.last_city_change,u.created_city,c.name country_name,ci.name city_name FROM users u JOIN countries c ON c.code=u.country_code LEFT JOIN cities ci ON ci.id=u.city_id WHERE u.id=?',[(int)$_SESSION['uid']])->fetch();return $u?:null;}
function fail(string $message,int $status=400):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'error'=>$message],JSON_UNESCAPED_UNICODE);exit;}
function out(array $value):never{header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode(['ok'=>true]+$value,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function auth():array{$u=user();if(!$u)fail('Oturum açmanız gerekiyor.',401);return $u;}
function admin():array{$u=auth();if($u['role']!=='admin')fail('Yetkiniz yok.',403);return $u;}
function audit(?int $id,string $event,string $details=''):void{sql('INSERT INTO audit_log(user_id,event,details) VALUES(?,?,?)',[$id,$event,substr($details,0,400)]);}
function activeWar(string $country):?array{return sql("SELECT w.*,p.side FROM wars w JOIN war_participants p ON p.war_id=w.id WHERE p.country_code=? AND w.status='active' LIMIT 1",[$country])->fetch()?:null;}
function penalty(string $code,string $type):bool{return (bool)sql('SELECT 1 FROM country_penalties WHERE country_code=? AND type=? AND expires_at>NOW() AND consumed=0 LIMIT 1',[$code,$type])->fetchColumn();}
function topLeader(string $country,int $id):bool{return (bool)sql('SELECT 1 FROM (SELECT id FROM users WHERE country_code=? ORDER BY total_clicks DESC,id ASC LIMIT 10) leaders WHERE id=?',[$country,$id])->fetchColumn();}
function eligible(int $id):bool{return (bool)sql('SELECT 1 FROM users WHERE id=? AND created_at < NOW() - INTERVAL 1 DAY AND total_clicks>=100 LIMIT 1',[$id])->fetchColumn();}
function notifyCountry(string $code,string $title,string $body):void{sql('INSERT INTO notices(country_code,title,body) VALUES(?,?,?)',[$code,$title,$body]);}
