<?php
// Copy this file to config.php and change values for your WAMP installation.
return [
 'db_host'=>'127.0.0.1','db_port'=>3306,'db_name'=>'tapglobia','db_user'=>'root','db_pass'=>'',
 'app_name'=>'TAPGLOBIA','app_url'=>'http://localhost/TAPGLOBIA',
 'session_secure'=>false, // set TRUE on HTTPS hosting
];
