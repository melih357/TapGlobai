# TAPGLOBIA — WAMP kurulum ve kullanım

Bu ZIP, PHP + MySQL üzerinde çalışan oynanabilir **ilk sürüm / test yapısıdır**. Ekranlar ve temel işlemler veritabanına bağlıdır; internete açılmadan önce gerçek trafik, güvenlik, hukuki uygunluk ve çoklu cihaz testleri yapılmalıdır.

## WAMP kurulumu (tek SQL dosyası)

1. ZIP'i açın; `TAPGLOBIA` klasörünü `C:\wamp64\www\` içine kopyalayın.
2. WAMP'ta Apache ve MySQL'i başlatın. PHP 8.2+ ve `pdo_mysql`, `mbstring`, `openssl` etkin olmalıdır.
3. `http://localhost/phpmyadmin` adresine gidin ve **yalnızca `sql/TAPGLOBIA_TEK_KURULUM.sql` dosyasını** *İçe Aktar* menüsünden içeri alın. SQL kendisi `tapglobia` veritabanını ve ülkeleri oluşturur. **Başka SQL yüklenmez.**
4. `config.example.php` dosyasını `config.php` olarak kopyalayıp içindeki `db_user`, `db_pass` ve gerekirse `db_host` alanlarını yerel WAMP ayarlarına göre düzenleyin.
5. Tarayıcıda `http://localhost/TAPGLOBIA/` adresine gidin, hesabınızı oluşturun.

**Hata çıkarsa:** WAMP/MySQL'in açık olduğunu, `pdo_mysql` eklentisini, `config.php` parolasını ve SQL'in sorunsuz içe aktarıldığını kontrol edin. Bu ortamda canlı MySQL bulunmadığından otomatik entegrasyon testi gerçekleştirilemedi.

## Türkçe / İngilizce dil desteği

Giriş ve kayıt ekranında ve oyun içindeki üst çubukta **TR / EN** butonları vardır. Ayarlar sayfasında da dil seçilebilir. Tercih tarayıcıda saklanır, sayfa yenilendikten sonra korunur. Navigasyon, giriş/kayıt, sıralama, ülke seçimi, oyun alanları ve sık kullanılan savaş/şehir ekranları çevrilebilir. Ülke adları seçilen dile göre gösterilir. Veritabanı kurulumu değişmez; **tek SQL dosyası** kullanılmaya devam eder. Bazı sunucu kaynaklı serbest metin ve eski bildirimler kayıt edildikleri dilde kalabilir.

## İstemci ekranları

Giriş / kayıt (yalnızca e-posta ve şifre), ISO ülke seçimi, normal basış ve savaş basışı, renk değiştiren ana ekran, ülke sıralaması, bireysel sıralama, şehir kurma ve katılma, şehir başvuruları, ülke değiştirme, saldırı teklifleri, saldırı oylaması, ittifak davet oylaması, desteğe katılma oylaması, aktif savaşlar ve sonucu, profil, ayarlar, admin istatistikleri ve ülke duyuruları.

## Geliştirilen kurallar

- Her yeni hesap, kayıt sırasında ülkesini seçer. Ülkelerin hepsi tek SQL dosyasında bulunur.
- Normal basış +1 kişisel ve ülke puanı sağlar. Şehirli kullanıcıda şehir katkısı da +1 olur, ancak ülkeye ikinci kez eklenmez.
- Ülke değiştirme: 50.000 kişisel basış ve son değişimden itibaren 30 gün; eski katkılar taşınmaz. Savaş sırasında değiştirilmez.
- Şehre katılma: 5.000 basış; şehir değiştirme: 10.000 basış ve 7 gün; şehir kurma: 50.000 basış ve tek kuruluş hakkı.
- En yüksek basışlı ilk 10 ülke oyuncusu saldırı teklif edebilir; ülkenin oyuncuları oylar.
- Bir saldırı teklifinin oylaması 12 saat sürer, ittifak davetleri 2 saat, aktif savaş desteği oylamaları 2 saat sürer.
- Oylama şartı: 100 basış, 1 günden eski hesap; %60 evet, en az 3 ve uygun üyelerin %10'una bağlı (en fazla 50) katılım. Az oyunculu ülkelerde ilk birkaç gün teklif kabul edilmeyebilir.
- Savaş başladığında saldıran her basışla savunmayı -1 düşürür; savunan önce kendi gücünü +1 yeniler, güç tam olduğunda saldıranın gücünü -1 düşürür. Savaş başlangıç gücü 10.000. Bir taraf sıfıra ulaşınca sonuç kesinleşir. 72 saatte sonuçlanmazsa berabere biter, transfer yapılmaz.
- Kazanan ittifakın ödülü, kaybeden ülkelerin savaş sonundaki puanlarının seçilen yüzdesidir. Kazananlar arasında geçerli savaş basışlarına oranla dağıtılır. Her kaybeden katılımcıya önceden ilan edilmiş ceza uygulanır.
- Basışlar sunucuda tekrar anahtarı ve saniyelik sınırla doğrulanır; teknik olarak insan-bot ayrımı kesin garanti edilemez. Gerçek para ödülü yoktur.

## Yönetici hesabı

Her normal kayıt `user` olarak başlar. Yalnızca **kendi güvenilir hesabınızı** phpMyAdmin SQL konsolunda şu komutla yönetici yapın:

`UPDATE tapglobia.users SET role='admin' WHERE username='KENDI_KULLANICI_ADINIZ';`

Bu işlem için ikinci SQL dosyası gerekmez. Yönetici panelinde özet istatistikler ve ülke duyurusu vardır.

## PWA ve yayın

`manifest.webmanifest`, `sw.js`, `icons/icon.svg` hazırdır. HTTPS yayın ortamı gereklidir; `localhost` geliştirici istisnasıdır. `config.php` dosyasında `session_secure` değerini HTTPS yayımlarken `true` yapın. Servis çalışanı yalnızca HTTPS'de kayıt olur (yerel HTTPS varsa da çalışır). Android ve iOS mağazaları için ayrıca paketleme ve mağaza hesapları gerekir.

## Yayın öncesi tamamlanması gerekenler

- Gerçek posta sunucusuyla **şifre sıfırlama/e-posta doğrulama**, e-posta teslimi ve hesap silme akışı.
- Çok kullanıcılı yüksek yük testi; MySQL işlem kilitlerini ve eşzamanlı savaş sonuçlarını stres testi.
- Bot/otomatik tıklama tespiti, IP/tabanlı kötüye kullanım önlemleri, kayıt ve giriş hız sınırlama, CAPTCHA, moderasyon ve erişim logları.
- Push bildirim altyapısı (şu an uygulama içi bildirim var; cihaz push bildirimleri yok).
- İttifak oylamasında ve destek katılımında güvenlik/denge kontrollerinin artırılması; şehir kurucu devri ve profil süreçlerinin uçtan uca testi.
- Kullanım koşulları, gizlilik politikası, yaş/ülke mevzuatı, çerez ve veri işleme uyumluluğu.
- Üretim sunucusunda `config.php` sunucudan dışarı sızdırılmamalıdır; servis kurallarını erişime kapatın, şifreleri değiştirin, otomatik yedek alın.
- Marka adı geçicidir; tescil ve alan adı uygunluğu henüz doğrulanmış değildir.

**Not:** Bu teslimat çalışan PHP kodları, UI ve tek SQL dosyası içerir; tüm dünyada güvenli, ölçeklenmiş ve bağımsız testleri tamamlanmış nihai yayın sürümü olduğu iddia edilmez.


## V8 SQL düzeltmesi
V7'deki `ALTER TABLE users ADD CONSTRAINT fk_users_city` satırı kaldırıldı.
Tek SQL dosyası: `sql/TAPGLOBIA_TEK_KURULUM.sql`.
Veritabanı kurulmuşsa sadece arayüzü güncellemek için yeniden SQL içe aktarmayın.
Başarısız içe aktarma sonrası yalnızca test verileri varsa boş veritabanında yeniden deneyin.
Gerçek kullanıcı verileri varsa veritabanını silmeden önce yedek alın.


## V9 — Sesler ve GitHub'a hazırlık
- Buton, menü, modal, oylama, ittifak, uyarı, zafer ve yenilgi efektleri için tarayıcıda oluşturulan özgün Web Audio sesleri eklendi (`assets/sound.js`).
- Ayarlar ekranından ses açma/kapatma, ses seviyesi ve örnek ses deneme kullanılabilir. Tarayıcı politikaları gereği ses ilk kullanıcı etkileşiminden sonra oynar.
- GitHub güvenliği için gerçek `config.php` arşivde **bulunmaz**; `config.example.php` dosyasını kopyalayarak oluşturun. `.gitignore` ve `README.md` eklendi.
- Kodları paylaşmak istemiyorsanız GitHub deposunu **Private** oluşturun. Public depo kaynak kodunu herkese gösterir.
- SQL dosyası hâlâ **tek** adettir; V8 kullanıyorsanız yeniden içe aktarmayın.
- Üretim ortamında tam test yapılmadı.

## V10 WAMP başlangıç düzeltmesi
WAMP varsayılan ayarlarındaysa ayrıca `config.php` oluşturmak gerekmez:
`bootstrap.php` localhost için otomatik olarak `config.example.php` ayarlarını kullanır.
Canlı sunucuya yüklenirken özel `config.php` gereklidir; GitHub'a yüklenmemelidir.
