/* TAPGLOBIA original synthesized sound effects. No external sound files or dependencies. */
(function () {
  'use strict';
  let ctx = null;
  let lastTapTime = 0;
  let lastNoticeKey = '';
  const pref = (key, fallback) => {
    try { const value = localStorage.getItem(key); return value === null ? fallback : value; }
    catch { return fallback; }
  };
  let enabled = pref('tgSoundEnabled', '1') === '1';
  let volume = Math.max(0, Math.min(1, Number(pref('tgSoundVolume', '.32')) || 0));
  function context() {
    const Constructor = window.AudioContext || window.webkitAudioContext;
    if (!Constructor) return null;
    if (!ctx) { try { ctx = new Constructor(); } catch { return null; } }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }
  function tone(freq, seconds, type, gain, offset = 0, endFreq = null) {
    const c = context(); if (!c) return;
    const start = c.currentTime + offset;
    const osc = c.createOscillator(), amp = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20,freq), start);
    if (endFreq !== null) osc.frequency.exponentialRampToValueAtTime(Math.max(20,endFreq), start + seconds);
    amp.gain.setValueAtTime(.0001, start);
    amp.gain.exponentialRampToValueAtTime(Math.max(.0002,gain * volume), start + .006);
    amp.gain.exponentialRampToValueAtTime(.0001, start + seconds);
    osc.connect(amp); amp.connect(c.destination);
    osc.start(start); osc.stop(start + seconds + .018);
  }
  const soundsets = {
    tap: () => tone(690,.068,'sine',.045,0,920),
    menu: () => tone(400,.085,'sine',.075,0,570),
    open: () => {tone(370,.10,'sine',.07);tone(555,.10,'sine',.07,.085);},
    close: () => tone(500,.105,'triangle',.055,0,320),
    vote: () => {tone(500,.09,'sine',.10);tone(750,.11,'sine',.10,.11);},
    alliance: () => [392,523,659,784].forEach((f,i)=>tone(f,.16,'sine',.09,i*.11)),
    attack: () => {tone(240,.16,'sawtooth',.10,0,130);tone(440,.13,'triangle',.085,.17,300);},
    warning: () => {tone(440,.16,'triangle',.11);tone(360,.19,'triangle',.10,.23);},
    victory: () => [392,494,587,784,988].forEach((f,i)=>tone(f,.21,'sine',.12,i*.14)),
    defeat: () => [460,390,300,225].forEach((f,i)=>tone(f,.22,'triangle',.095,i*.17)),
    achievement: () => [523,659,784].forEach((f,i)=>tone(f,.18,'sine',.10,i*.10)),
    error: () => {tone(230,.13,'triangle',.085);tone(185,.18,'triangle',.07,.14);},
    notification: () => {tone(680,.10,'sine',.075);tone(840,.12,'sine',.07,.13);}
  };
  function play(kind) {
    if (!enabled || volume<=0 || document.hidden) return;
    if (kind === 'tap') { const now = performance.now(); if (now-lastTapTime < 38) return; lastTapTime = now; }
    try { (soundsets[kind] || soundsets.menu)(); } catch { /* Browser without audio support */ }
  }
  window.TAP_sound = {
    play, unlock: context,
    isEnabled: () => enabled,
    getVolume: () => Math.round(volume * 100),
    setEnabled(v) { enabled=!!v; try{localStorage.setItem('tgSoundEnabled', enabled?'1':'0');}catch{} if(enabled)play('menu'); },
    setVolume(v) { volume = Math.max(0,Math.min(1,Number(v)/100)); try{localStorage.setItem('tgSoundVolume',String(volume));}catch{} },
    notifyOnce(key) { if (key !== lastNoticeKey) { lastNoticeKey=key;play('notification'); } }
  };
  document.addEventListener('pointerdown', () => { if(enabled)context(); }, {once:true, passive:true});
})();
