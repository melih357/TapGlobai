# TAPGLOBIA — PWA Game (development build)

A PHP/MySQL progressive web game prototype featuring country rankings, optional player-created cities, click battles, voting, and alliances, with Turkish and English interface support.

> **Development build, not production audited.** Requires security, concurrency, accessibility, legal, and device testing before public deployment.

## Local WAMP installation

1. Place the `TAPGLOBIA` directory in `C:\\wamp64\\www\\`.
2. Import **only** `sql/TAPGLOBIA_TEK_KURULUM.sql` using phpMyAdmin. It creates database `tapglobia` and country data.
3. Copy `config.example.php` to `config.php` and set your local database credentials.
4. Start Apache and MySQL, then open `http://localhost/TAPGLOBIA/`.

Existing V8 databases do **not** require a new SQL import for V9 sound effects.

## Sound effects

Original synthesized Web Audio sounds for tapping, navigation, alerts, voting, alliances, victory, and defeat. No external audio files, music, licenses, or third-party audio dependencies. Sounds play only after a user gesture and can be muted or adjusted under **Settings > Ses ayarları / Sound settings**. Preferences are stored locally. Some browsers or device settings may suppress sounds.

## GitHub safety

- **Use a private repository** if you do not want to distribute the source code. A public GitHub repository makes the uploaded source available to others. `.gitignore` is not a copyright or secrecy mechanism.
- `config.php` is **not included** in the ZIP. Never commit your real database password, API keys, private user data, backups, or SQL exports containing user records.
- `config.example.php` is only a sample with local WAMP defaults.
- This package deliberately ships with **no open-source license**. That does not keep a public repository private; it only means no general reuse license is granted.
- Before deploying publicly, change production credentials, use HTTPS with secure sessions, and review the security TODOs in `KURULUM_VE_KULLANIM.md`.

## Language

TR / EN buttons are available during authentication and in-app. Some older/dynamic messages may not be translated completely.

## Caveats

GitHub ZIP is a source distribution intended for private storage and your local development; not a fully tested public release. Push notifications, email verification and reset, password recovery, full bot defenses and high-load tests remain future work.

## V10: Eksik config.php düzeltmesi

- `localhost` ve `127.0.0.1` üzerinden WAMP testinde `config.php` yoksa uygulama otomatik olarak `config.example.php` dosyasındaki **yerel varsayılanları** kullanır.
- Yerel MySQL ayarlarınız farklıysa `config.example.php` dosyasını `config.php` olarak kopyalayıp kendi bilgilerinizi yazın.
- İnternette yayımlarken `config.php` mutlaka oluşturulmalıdır. Bu dosyayı GitHub'a yüklemeyin.
- Yerel varsayılan veritabanı adı `tapglobia`, kullanıcı `root`, şifre boş, port `3306` olarak ayarlanmıştır.
